
from application import main

if __name__ == '__main__':
    main.run() 
 

#flask_debug=1
#flask_developer