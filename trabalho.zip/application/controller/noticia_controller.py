from flask import render_template
from application import main
from application.model.dao.noticias_dao import NoticiasDao



@main.route("/noticia/<int:id>")

def exibir_noticia(id):
    noticias_dao = NoticiasDao.listar_noticia()
    for estado in noticias_dao:
        for a in  estado.get_noticia_lista(): 
            if a.get_id() == id:
                return render_template("exibir-noticia.html",
                    noticia=a,
                    )
            
    return render_template("home.html", noticias=noticias_dao)



