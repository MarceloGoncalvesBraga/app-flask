from flask import render_template
from application import main
from application.model.dao.noticias_dao import NoticiasDao


@main.route("/")
def home():
    noticias_pux = NoticiasDao.listar_noticia()
    return render_template("lista_noticias.html",
        noticias = noticias_pux,
        )
            



