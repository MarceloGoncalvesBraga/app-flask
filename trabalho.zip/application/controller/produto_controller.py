from flask import render_template
from application import main
from application.model.dao.produto_dao import ProdutoDao


    return render_template("produtos.html",
    produtos = ProdutoDao.listar_produto()       
                           
    )
    
from flask import render_template
from application import main
from application.model.dao.noticia_dao import NoticiaDao

@app.route("/estado/<string:uf>")
def noticias_do_estado(uf):
    for estado in estado_lista:
        if estado.get_uf() == uf:
            return render_template("exibir-noticias-do-estado.html", 
                                   noticias = bubbleSort(estado.get_noticia_lista())

                                    menus = estado_lista,
                                    estado = estado.get_uf()
                                   )
    return render_template("home.html", noticias=estado_lista)



@app.route("/noticia/<int:id>")
def exibir_noticia(id):
    for estado in estado_lista:
        for a in  estado.get_noticia_lista(): 
            if a.get_id() == id:
                return render_template("exibir-noticia.html",
                    noticia=a,
                     menus = estado_lista
                    )
            
    return render_template("home.html", noticias=estado_lista)



